
export default {
  failed: 'Action failed',
  success: 'Action was successful'
}
