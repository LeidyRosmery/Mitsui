/*
export function someMutation (state) {
}
*/
