import enUS from './en-us'
import  Sp from './es'

export default {
  'en-us': enUS,
  'es':Sp
}
