<template>
  <div id="q-app" :style="'height:100vh !important;position: absolute;overflow: scroll;'"  >
    <router-view/>
     <!--<transition   enter-active-class="animated zoomOut" mode="out-in" appear>
        <router-view/>
     </transition>-->
  </div>
</template>
<script>
export default {
  name: 'App',
  methods: {
      //  mora:function() {         
      //    console.log("holaaa");
      //  }
    }
  }

</script>

<style/>