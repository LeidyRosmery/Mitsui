export default
{
    /*Generator*/
        keyUtil       : 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=',
        keyRandom     : ["M=Ga","VCaK","OP=Q","NNOA","McXs","ZZ=Q","LJGS","PNk=","qswf","ZVs2","qaSa","LNms","CzSQ","Nlsd","SSd=","HGas","MRTG","KhRt","lGtR","BvRt","AzsF","JkTr","HGas","QRXG","KhRt","PGtR","Avtt","AzsF","Fkxr"],
    /*Http*/
        contentType   : 'application/json',
        sAplicacion   : 'Movil',
        authorization : 'Basic TUlUU1VJQ0lUQVNNT1ZJTDpTZWlkb3JAUGVydSQxMjM0NTYk',
        authorizationPRD : 'Basic TUlUU1VJQ0lUQVNQUkQ6U2VpZG9yQFBlcnUkNzg5JA==',
        stoken        : 'AzsFbHVpc21vcmFwYW50b2phIyQkQEBAMTIzNA==',
    /*Register */
        tipoUsuario  :16,
    /*Servicies */
        pointer_aut  : ['iCode'],
        element_aut  : ['iPuntos','sEmail','sNombre','sNumIdentificacion'],
    /*Login*/
        lg_validator : 'Correo o contraseña incorrectos.',
        lg_change    : 'Ingrese un email correcto',
        lg_authen    : 'Validando credenciales ...',
        lg_create    : 'Registrando Usuario ...',
        lg_recover   : 'Enviando Información ...',
    /*Home*/
        hm_start     : 'Cargando Información ...',
        hm_element   : ['iId'],
        texto_calendario: 'Tiene reservada una cita para su vehiculo {{P_MODELO}} ({{P_PLACA}}) en el {{P_TALLER}}',
        isPRD: true
}
