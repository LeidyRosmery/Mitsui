<template>
    <q-layout class="ground">
        <div class="fixed-center">         
            <!--<img src="assets/images/ic_mitsui.png" class="logoSplash animated flip slower 2s">-->
            <img src="~assets/images/ic_mitsui.png" class="logoSplash">
        </div> 
    </q-layout>
</template>
<script src="../js/splash.js"/>